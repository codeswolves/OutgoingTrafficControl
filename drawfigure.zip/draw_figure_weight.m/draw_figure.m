%��������
namelist = dir('D:\MyPaper\2Outgoing\2Register\register\fourth experiment\5twoDirection\data_weight\LTR\');
len=length(namelist);
for i = 1:len
      file_name = namelist(i).name;
      if  strcmp(file_name,'.') || strcmp(file_name,'..')
          continue
      end
      file_nameF=['./data_weight/LTR/',file_name];
      Data=importdata(file_nameF);
      %disp(file_name);
      array = Data.data;
      figure('visible','off');
      %OMLeft= array(:,1);
      %SMLeft= array(:,2);
      %NELeft=array(:,3);
      %OMRight=array(:,4);
      %SMRight=array(:,5);
      %NERight=array(:,6);
      OMTotal= array(:,7);
      SMTotal= array(:,8);
      NETotal= array(:,9); 
      OMGain=SMTotal-OMTotal;
      NEGain=SMTotal-NETotal;
      %ɾ��С��0�ġ�
      for j=1:length(NEGain)
          if NEGain(j) < 0
              if OMGain(j) >=0
                  NEGain(j)=OMGain(j);
              else
                  NEGain(j)=0;
              end
          end
      end
      OMGainP= (OMGain./SMTotal)*100;
      NEGainP=(NEGain./SMTotal)*100;
      OM=cdfplot(OMGainP);
      hold on;
      NG=cdfplot(NEGainP);
      set(gca,'YTick',(0:0.1:1));
      set(gca,'XTick',(0:10:100));
      set(gca,'XLim',[0 100]);
      set(OM,'LineStyle','-','LineWidth',2,'Color','r');
      set(NG,'LineStyle',':','LineWidth',2,'Color','b');
      legend('OM','NBREG','Location','best');
      ylabel('������ۻ��ֲ� / %','Fontname','����','FontSize',14);
      xlabel('������ / %','Fontname','����','FontSize',14);
      str= strsplit(file_name,'_');
      titlename=['����ϵͳ',str{1},'-','����ϵͳ',str{2}];
      title(titlename);
      outputname=[file_name,'.png'];
      saveas(gcf,['./Total/weight/percentage_gain/LTR/',outputname]);
end
close all;
fclose('all');