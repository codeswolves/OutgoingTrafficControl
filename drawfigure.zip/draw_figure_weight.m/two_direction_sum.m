%˫����ע�������
namelist = dir('D:\MyPaper\2Outgoing\2Register\register\Fourth experiment\5twoDirection\data_weight\LTR\');
namelist2 = dir('D:\MyPaper\2Outgoing\2Register\register\Fourth experiment\5twoDirection\data_weight\RTL\');
len=length(namelist);
%temp_OMLTR=[];
%temp_NegLTR=[];
%temp_OMRightLTR=[];
%temp_OMLeftLTR=[];
%temp_NegLeftLTR=[];
%temp_NegRightLTR=[];
temp_OM=[];
temp_Neg=[];
temp_OMRight=[];
temp_OMLeft=[];
temp_NegLeft=[];
temp_NegRight=[];
for i = 1:len
      file_name = namelist(i).name;
      if strcmp(file_name,'.') || strcmp(file_name,'..') 
          continue
      end
      Data=[];
      Data2=[];
      file_nameF=['./data_weight/LTR/',file_name];
      file_nameF2=['./data_weight/RTL/',file_name];
      %disp(file_name);
      Data=importdata(file_nameF);
      Data2=importdata(file_nameF2);
      array = Data.data;
      OMTotal= array(:,7);
      SMTotal= array(:,8);
      NETotal= array(:,9);
      OMLeft= array(:,1);
      SMLeft= array(:,2);
      NELeft=array(:,3);
      OMRight=array(:,4);
      SMRight=array(:,5);
      NERight=array(:,6);
      OMGainLTR=SMTotal-OMTotal;
      NEGainLTR=SMTotal-NETotal;
      OMGainLeftLTR=SMLeft-OMLeft;
      NEGainLeftLTR=SMLeft-NELeft;
      OMGainRightLTR=SMRight-OMRight;
      NEGainRightLTR=SMRight-NERight;
      for j=1:length(NEGainLTR)
          if NEGainLTR(j) < 0
              if OMGainLTR(j) >=0
                  NEGainLTR(j)=OMGainLTR(j);
                  NEGainLeftLTR(j)=OMGainLeftLTR(j);
                  NEGainRightLTR(j)=OMGainRightLTR(j);
              else
                  NEGainLTR(j)=0;
                  NEGainLeftLTR(j)=0;
                  NEGainRightLTR(j)=0;
              end
          end
      end
      %OMGainP=(OMGain./SMTotal)*100;
      %NEGainP=(NEGain./SMTotal)*100;
      %OMGainLeftP= (OMGainLeft./SMTotal)*100;
      %NEGainLeftP=(NEGainLeft./SMTotal)*100;
      %OMGainRightP= (OMGainRight./SMTotal)*100;
      %NEGainRightP=(NEGainRight./SMTotal)*100;
      %temp_OMLTR=[temp_OMLTR,mean(OMGainP)];
      %temp_NegLTR=[temp_NegLTR,mean(NEGainP)];
      %temp_NegLeftLTR = [temp_NegLeftLTR,mean(NEGainLeftP)];
      %temp_OMLeftLTR = [temp_OMLeftLTR,mean(OMGainLeftP)];
      %temp_OMRightLTR = [temp_OMRightLTR,mean(OMGainRightP)];
      %temp_NegRightLTR = [temp_NegRightLTR,mean(NEGainRightP)];
      %a=mean(NEGainLeft);
      %�ھ�
      array = Data2.data;
      OMTotal= array(:,7);
      SMTotal= array(:,8);
      NETotal= array(:,9);
      OMLeft= array(:,1);
      SMLeft= array(:,2);
      NELeft=array(:,3);
      OMRight=array(:,4);
      SMRight=array(:,5);
      NERight=array(:,6);
      OMGainRTL=SMTotal-OMTotal;
      NEGainRTL=SMTotal-NETotal;
      OMGainLeftRTL=SMLeft-OMLeft;
      NEGainLeftRTL=SMLeft-NELeft;
      OMGainRightRTL=SMRight-OMRight;
      NEGainRightRTL=SMRight-NERight;
      for j=1:length(NEGainRTL)
         if NEGainRTL(j) < 0
             if OMGainRTL(j) >=0
                 NEGainRTL(j)=OMGainRTL(j);
                 NEGainLeftRTL(j)=OMGainLeftRTL(j);
                 NEGainRightRTL(j)=OMGainRightRTL(j);
             else
                NEGainRTL(j)=0;
                 NEGainLeftRTL(j)=0;
                 NEGainRightRTL(j)=0;
             end
         end
      end
      %OMGainP=(OMGain./SMTotal)*100;
      %NEGainP=(NEGain./SMTotal)*100;
      %OMGainLeftP= (OMGainLeft./SMTotal)*100;
      %NEGainLeftP=(NEGainLeft./SMTotal)*100;
      %OMGainRightP= (OMGainRight./SMTotal)*100;
      %NEGainRightP=(NEGainRight./SMTotal)*100;
      OG=mean(OMGainLTR)+mean(OMGainRTL);
      if OG > 1000
          disp(file_name);
      end
      NG=mean(NEGainLTR)+mean(NEGainRTL);
      temp_OM=[temp_OM,OG];
      temp_Neg=[temp_Neg,NG];
      OGL=mean(OMGainLeftLTR)+mean(OMGainLeftRTL);
      NGL=mean(NEGainLeftLTR)+mean(NEGainLeftRTL);
      temp_NegLeft = [temp_NegLeft,NGL];
      temp_OMLeft = [temp_OMLeft,OGL];
      OGR=mean(OMGainRightLTR)+mean(OMGainRightRTL);
      NGR=mean(NEGainRightLTR)+mean(NEGainRightRTL);
      temp_OMRight = [temp_OMRight,OGR];
      temp_NegRight = [temp_NegRight,NGR];
end
%��ͼ
figure('visible','off');
subplot(3,1,1);
OM=cdfplot(temp_OM);
hold on;
NG=cdfplot(temp_Neg);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(0:10:100));
%set(gca,'XLim',[0 100]);
legend('OM','NBREG','Location','best');
set(gca,'Xlabel',[]);
set(gca,'Ylabel',[]);
%,'Marker','*','MarkerSize',5
set(OM,'LineStyle','-','LineWidth',2,'Color','red');
set(NG,'LineStyle',':','LineWidth',2,'Color','blue');
title('����');
subplot(3,1,2);
OML=cdfplot(temp_OMLeft);
hold on;
NGL=cdfplot(temp_NegLeft);
legend('OM','NBREG','Location','best');
set(gca,'Xlabel',[]);
ylabel('322������ϵͳ�Ե��ۻ��ֲ�','Fontname','����','FontSize',14);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(-100:10:0));
%set(gca,'XLim',[-100 0]);
set(OML,'LineStyle','-','LineWidth',2,'Color','red');
set(NGL,'LineStyle',':','LineWidth',2,'Color','blue');
title('������ϵͳ');
subplot(3,1,3);
OMR=cdfplot(temp_OMRight);
hold on;
NGR=cdfplot(temp_NegRight);
legend('OM','NBREG','Location','best');
xlabel('ƽ������ / Ȩ��','Fontname','����','FontSize',14);
set(gca,'Ylabel',[]);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(0:10:100));
%set(gca,'XLim',[0 100]);
set(OMR,'LineStyle','-','LineWidth',2,'Color','red');
set(NGR,'LineStyle',':','LineWidth',2,'Color','blue');
title('������ϵͳ');
%saveas(gcf,'./two_direction_add/weight/allASPairAverageGain.png');
%saveas(gcf,'./two_direction_add/weight/allASPairAverageGain.fig');
close all;
fclose('all');