%˫����ע�������
namelist = dir('D:\MyPaper\2Outgoing\2Register\register\Fourth experiment\5twoDirection\data_hopnumber\LTR\');
namelist2 = dir('D:\MyPaper\2Outgoing\2Register\register\Fourth experiment\5twoDirection\data_hopnumber\RTL\');
len=length(namelist);
temp_OMLTR=[];
temp_NegLTR=[];
temp_OMRightLTR=[];
temp_OMLeftLTR=[];
temp_NegLeftLTR=[];
temp_NegRightLTR=[];
temp_OMRTL=[];
temp_NegRTL=[];
temp_OMRightRTL=[];
temp_OMLeftRTL=[];
temp_NegLeftRTL=[];
temp_NegRightRTL=[];
for i = 1:len
      file_name = namelist(i).name;
      if strcmp(file_name,'.') || strcmp(file_name,'..') 
          continue
      end
      Data=[];
      Data2=[];
      file_nameF=['./data_hopnumber/LTR/',file_name];
      file_nameF2=['./data_hopnumber/RTL/',file_name];
      %disp(file_name);
      Data=importdata(file_nameF);
      Data2=importdata(file_nameF2);
      array = Data.data;
      OMTotal= array(:,7);
      SMTotal= array(:,8);
      NETotal= array(:,9);
      OMLeft= array(:,1);
      SMLeft= array(:,2);
      NELeft=array(:,3);
      OMRight=array(:,4);
      SMRight=array(:,5);
      NERight=array(:,6);
      OMGain=SMTotal-OMTotal;
      NEGain=SMTotal-NETotal;
      OMGainLeft=SMLeft-OMLeft;
      NEGainLeft=SMLeft-NELeft;
      OMGainRight=SMRight-OMRight;
      NEGainRight=SMRight-NERight;
      for j=1:length(NEGain)
          if NEGain(j) < 0
              if OMGain(j) >=0
                  NEGain(j)=OMGain(j);
                  NEGainLeft(j)=OMGainLeft(j);
                  NEGainRight(j)=OMGainRight(j);
              else
                  NEGain(j)=0;
                  NEGainLeft(j)=0;
                  NEGainRight(j)=0;
              end
          end
      end
      OMGainP=(OMGain./SMTotal)*100;
      NEGainP=(NEGain./SMTotal)*100;
      OMGainLeftP= (OMGainLeft./SMTotal)*100;
      NEGainLeftP=(NEGainLeft./SMTotal)*100;
      OMGainRightP= (OMGainRight./SMTotal)*100;
      NEGainRightP=(NEGainRight./SMTotal)*100;
      temp_OMLTR=[temp_OMLTR,mean(OMGainP)];
      temp_NegLTR=[temp_NegLTR,mean(NEGainP)];
      temp_NegLeftLTR = [temp_NegLeftLTR,mean(NEGainLeftP)];
      temp_OMLeftLTR = [temp_OMLeftLTR,mean(OMGainLeftP)];
      a=mean(OMGainLeftP);
      temp_OMRightLTR = [temp_OMRightLTR,mean(OMGainRightP)];
      temp_NegRightLTR = [temp_NegRightLTR,mean(NEGainRightP)];
      %�ھ�
      array = Data2.data;
      OMTotal= array(:,7);
      SMTotal= array(:,8);
      NETotal= array(:,9);
      OMLeft= array(:,1);
      SMLeft= array(:,2);
      NELeft=array(:,3);
      OMRight=array(:,4);
      SMRight=array(:,5);
      NERight=array(:,6);
      OMGain=SMTotal-OMTotal;
      NEGain=SMTotal-NETotal;
      OMGainLeft=SMLeft-OMLeft;
      NEGainLeft=SMLeft-NELeft;
      OMGainRight=SMRight-OMRight;
      NEGainRight=SMRight-NERight;
      for j=1:length(NEGain)
          if NEGain(j) < 0
              if OMGain(j) >=0
                  NEGain(j)=OMGain(j);
                  NEGainLeft(j)=OMGainLeft(j);
                  NEGainRight(j)=OMGainRight(j);
              else
                  NEGain(j)=0;
                  NEGainLeft(j)=0;
                  NEGainRight(j)=0;
              end
          end
      end
      OMGainP=(OMGain./SMTotal)*100;
      NEGainP=(NEGain./SMTotal)*100;
      OMGainLeftP= (OMGainLeft./SMTotal)*100;
      NEGainLeftP=(NEGainLeft./SMTotal)*100;
      OMGainRightP= (OMGainRight./SMTotal)*100;
      NEGainRightP=(NEGainRight./SMTotal)*100;
      temp_OMRTL=[temp_OMRTL,mean(OMGainP)];
      temp_NegRTL=[temp_NegRTL,mean(NEGainP)];
      temp_NegLeftRTL = [temp_NegLeftRTL,mean(NEGainLeftP)];
      temp_OMLeftRTL = [temp_OMLeftRTL,mean(OMGainLeftP)];
      b=mean(OMGainLeftP);
      temp_OMRightRTL = [temp_OMRightRTL,mean(OMGainRightP)];
      temp_NegRightRTL = [temp_NegRightRTL,mean(NEGainRightP)];
      if a+b <0
          disp(file_name);
      end
end
temp_OM=temp_OMLTR + temp_OMRTL;
temp_Neg=temp_NegLTR+temp_NegRTL;
temp_OMLeft=temp_OMLeftLTR+temp_OMLeftRTL;
temp_NegLeft=temp_NegLeftLTR+temp_NegLeftRTL;
temp_OMRight=temp_OMRightLTR+temp_OMRightRTL;
temp_NegRight=temp_NegRightLTR+temp_NegRightRTL;
%��ͼ
figure('visible','off');
subplot(3,1,1);
OM=cdfplot(temp_OM);
hold on;
NG=cdfplot(temp_Neg);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(0:10:100));
%set(gca,'XLim',[0 100]);
legend('OM','NBREG','Location','best');
set(gca,'Xlabel',[]);
set(gca,'Ylabel',[]);
%,'Marker','*','MarkerSize',5
set(OM,'LineStyle','-','LineWidth',2,'Color','red');
set(NG,'LineStyle',':','LineWidth',2,'Color','blue');
title('˫����ע��');
subplot(3,1,2);
OML=cdfplot(temp_OMLeft);
hold on;
NGL=cdfplot(temp_NegLeft);
legend('OM','NBREG','Location','best');
set(gca,'Xlabel',[]);
ylabel('����ϵͳ�Ե��ۻ��ֲ� / %','Fontname','����','FontSize',14);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(-100:10:0));
%set(gca,'XLim',[-100 0]);
set(OML,'LineStyle','-','LineWidth',2,'Color','red');
set(NGL,'LineStyle',':','LineWidth',2,'Color','blue');
title('������ϵͳ');
subplot(3,1,3);
OMR=cdfplot(temp_OMRight);
hold on;
NGR=cdfplot(temp_NegRight);
legend('OM','NBREG','Location','best');
xlabel('ƽ������ / %','Fontname','����','FontSize',14);
set(gca,'Ylabel',[]);
set(gca,'YTick',(0:0.2:1));
%set(gca,'XTick',(0:10:100));
%set(gca,'XLim',[0 100]);
set(OMR,'LineStyle','-','LineWidth',2,'Color','red');
set(NGR,'LineStyle',':','LineWidth',2,'Color','blue');
title('������ϵͳ');
saveas(gcf,'./two_direction_add/hopnumber/allASPairAverageGain.png');
saveas(gcf,'./two_direction_add/hopnumber/allASPairAverageGain.fig');
close all;
fclose('all');